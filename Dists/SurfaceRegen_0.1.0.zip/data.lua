
data:extend({

	{
		type = "custom-input",
		name = "Show-SurfaceGen-GUI",
		key_sequence = "CONTROL + SHIFT + C",
		consuming = "none"
	}

})